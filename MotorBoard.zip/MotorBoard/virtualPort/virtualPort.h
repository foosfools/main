/*
* virtualPort.h
*/

int virtualPort_open();

int configure_port (int fd);

//EOF